#### Description

###### hw2_lssvm_all.dat is both testing data and training data for linear ridge regression for classification 
###### hw2_lssvm_all.dat is both testing data and training data for bagging linear ridge regression for classification
###### hw2_adaboost_test.dat and hw2_adaboost_train.dat are testing data and training data for AdaBoost respectively

#### Usage
<pre><code>python3 hw2_ridge_reg.py ./data/hw2_lssvm_all.dat</code></pre>
<pre><code>python3 hw2_ridge_reg_bag.py ./data/hw2_lssvm_all.dat</code></pre>
<pre><code>python3 hw2_adaboost_stump.py ./data/hw2_adaboost_train.dat ./data/hw2_adaboost_test.dat</code></pre>